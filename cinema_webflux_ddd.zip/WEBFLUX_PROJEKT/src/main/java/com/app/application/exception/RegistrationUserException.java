package com.app.application.exception;

public class RegistrationUserException extends RuntimeException {
    public RegistrationUserException(String message) {
        super(message);
    }
}
