package com.app.application.exception;

public class MovieEmissionServiceException extends RuntimeException {

    public MovieEmissionServiceException(String message) {
        super(message);
    }
}
