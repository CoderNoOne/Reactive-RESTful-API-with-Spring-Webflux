package com.app.domain.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Position {

    private Integer rowNo;
    private Integer colNo;
}
