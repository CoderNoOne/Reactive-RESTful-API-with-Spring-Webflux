package com.app.domain.ticket;

import com.app.domain.generic.CrudRepository;

public interface TicketRepository extends CrudRepository<Ticket, String> {
}
