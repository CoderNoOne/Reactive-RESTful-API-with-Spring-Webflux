package com.app.domain.ticket_order.enums;

public enum TicketOrderType {
    FAMILY,
    NORMAL;
}
