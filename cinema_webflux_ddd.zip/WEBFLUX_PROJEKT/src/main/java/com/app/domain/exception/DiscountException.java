package com.app.domain.exception;

public class DiscountException extends RuntimeException {
    public DiscountException(String message) {
        super(message);
    }
}
