package com.app.domain.cinema_hall;

import com.app.domain.generic.CrudRepository;

public interface CinemaHallRepository extends CrudRepository<CinemaHall, String> {
}
