package com.app.domain.movie;

import com.app.domain.generic.CrudRepository;

public interface MovieRepository extends CrudRepository <Movie, String> {
}
