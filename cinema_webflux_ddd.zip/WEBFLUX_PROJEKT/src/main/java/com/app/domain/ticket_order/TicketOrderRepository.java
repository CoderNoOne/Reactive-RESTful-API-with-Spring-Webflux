package com.app.domain.ticket_order;

import com.app.domain.generic.CrudRepository;

public interface TicketOrderRepository extends CrudRepository<TicketOrder, String> {
}
